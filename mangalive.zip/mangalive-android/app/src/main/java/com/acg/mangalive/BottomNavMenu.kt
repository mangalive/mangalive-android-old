package com.acg.mangalive

import android.content.Context
import com.google.android.material.bottomnavigation.BottomNavigationMenuView

class BottomNavMenu(context: Context) : BottomNavigationMenuView(context) {

}